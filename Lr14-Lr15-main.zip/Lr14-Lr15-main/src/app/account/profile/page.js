export const metadata = {
  title: "Profile | Your account",
};

export default function Page() {
  return <div>Your profile</div>;
}

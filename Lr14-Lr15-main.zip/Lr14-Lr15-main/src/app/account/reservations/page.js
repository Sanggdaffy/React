export const metadata = {
  title: "Reservations | Your account",
};

export default function Page() {
  return <div>Your reservations</div>;
}
